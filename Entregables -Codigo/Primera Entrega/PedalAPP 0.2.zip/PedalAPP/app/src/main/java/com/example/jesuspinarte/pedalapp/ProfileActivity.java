package com.example.jesuspinarte.pedalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    Intent intent_info;
    Bundle bundle;
    TextView username;
    TextView city;
    Button friend_list;
    Button create_route;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        intent_info = getIntent();
        bundle = intent_info.getBundleExtra("bundle");
        username = (TextView) findViewById(R.id.tv_username);
        city = (TextView) findViewById(R.id.tv_city);
        friend_list = (Button) findViewById(R.id.bt_friends);
        create_route = (Button) findViewById(R.id.bt_create_route);
        update = (Button) findViewById(R.id.bt_update);

        username.setText(bundle.getString("name"));
        city.setText(bundle.getString("city"));

        friend_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), FriendListActivity.class);
                intent.putExtra("bundle", bundle);
                startActivity(intent, bundle);
            }
        });

        create_route.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CreateRouteActivity.class);
                startActivity(intent);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), UpdateProfileActivity.class);
                intent.putExtra("bundle", bundle);
                startActivity(intent, bundle);
            }
        });


    }
}
