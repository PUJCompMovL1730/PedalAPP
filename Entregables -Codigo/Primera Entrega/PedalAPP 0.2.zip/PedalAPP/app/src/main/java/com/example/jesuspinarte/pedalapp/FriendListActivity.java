package com.example.jesuspinarte.pedalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class FriendListActivity extends AppCompatActivity {

    ArrayList<String> friends;
    ListView friend_list;
    Button add_friend;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_list);

        bundle = getIntent().getBundleExtra("bundle");
        friend_list = (ListView) findViewById(R.id.lv_friend_list);
        add_friend = (Button) findViewById(R.id.bt_add_friend);

        friends = new ArrayList<String>();

        try {
            JSONObject json = new JSONObject(loadJSONFromAsset());
            JSONArray paisesJsonArray = json.getJSONArray("friends");
            for (int i = 0; i < paisesJsonArray.length(); i++) {
                JSONObject jsonObject = paisesJsonArray.getJSONObject(i);
                friends.add(jsonObject.getString("user"));
            }
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>( this, android.R.layout.simple_list_item_1, friends);
        friend_list.setAdapter(adapter);

        add_friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), AddFriendActivity.class);
                intent.putExtra("bundle", bundle);
                startActivity(intent, bundle);
            }
        });


    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("friends.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
