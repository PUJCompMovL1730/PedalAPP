package com.example.jesuspinarte.pedalapp;

import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CreateRouteActivity extends AppCompatActivity {

    EditText txtRoute_name;
    EditText txtBegin;
    EditText txtEnd;

    LinearLayout llayout;

    Button btnCreate_route;

    TextView mensajeExitoso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_route);

        llayout = (LinearLayout) findViewById(R.id.ll_create_route);

        txtRoute_name = (EditText) findViewById(R.id.et_route_name);
        txtBegin = (EditText) findViewById(R.id.et_begin);
        txtEnd = (EditText) findViewById(R.id.et_end);

        btnCreate_route = (Button) findViewById(R.id.bt_create_route);

        mensajeExitoso = (TextView) findViewById(R.id.tv_route_created);

        btnCreate_route.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String route_name = txtRoute_name.getText().toString();
                String begin = txtBegin.getText().toString();
                String end = txtEnd.getText().toString();

                if( TextUtils.isEmpty(route_name) || TextUtils.isEmpty(begin) || TextUtils.isEmpty(end) ){
                    CharSequence text = "Error: Falta llenar alguno de los campos";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(v.getContext(), text, duration);
                    toast.show();
                }else{
                    mensajeExitoso.setText("La ruta \""+route_name+"\" fue creada satisfactoriamente");
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        mensajeExitoso.setText("");
    }
}
