package com.example.jesuspinarte.pedalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateProfileActivity extends AppCompatActivity {

    EditText txtUsername;
    EditText txtActPassword;
    EditText txtNewPassword;
    EditText txtNewPasswordVerify;

    Spinner spCities;

    Button btnCommitUpdate;
    Button btnCommitDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        txtUsername = (EditText) findViewById(R.id.et_username);
        txtActPassword = (EditText) findViewById(R.id.et_actual_password);
        txtNewPassword = (EditText) findViewById(R.id.et_new_password);
        txtNewPasswordVerify = (EditText) findViewById(R.id.et_new_password_verify);

        spCities = (Spinner) findViewById(R.id.s_cities);

        btnCommitUpdate = (Button) findViewById(R.id.bt_commit_update);
        btnCommitDelete = (Button) findViewById(R.id.bt_commit_delete);

        btnCommitUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = txtUsername.getText().toString();
                String actPassword = txtActPassword.getText().toString();
                String newPassword = txtNewPassword.getText().toString();
                String newPasswordVerify = txtNewPasswordVerify.getText().toString();

                if( TextUtils.isEmpty(actPassword)){
                    CharSequence text = "Error: Primero debe poner su contraseña actual ";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(v.getContext(), text, duration);
                    toast.show();
                }else{
                    if(TextUtils.isEmpty(newPassword) && TextUtils.isEmpty(newPasswordVerify)){
                        CharSequence text2 = "Datos personales actualizados";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(v.getContext(), text2, duration);
                        toast.show();
                    }else{
                        if(newPassword.equals(newPasswordVerify)){
                            CharSequence text2 = "Contraseña actualizada";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(v.getContext(), text2, duration);
                            toast.show();
                        }else{
                            CharSequence text2 = "Las contraseñas no coinciden";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(v.getContext(), text2, duration);
                            toast.show();
                        }
                    }

                }

            }
        });

        btnCommitDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),MainActivity.class);
                startActivity(intent);
            }
        });


    }
}
