package com.example.jesuspinarte.pedalapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class AddFriendActivity extends AppCompatActivity {

    ArrayList<String[]> users;
    Bundle bundle;
    Button add_friend;
    EditText friend_username;
    boolean user_exists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);

        bundle = getIntent().getBundleExtra("bundle");
        users = new ArrayList<String[]>();
        add_friend = (Button) findViewById(R.id.bt_add_friend_commit);
        friend_username = (EditText) findViewById(R.id.et_friend_username);
        user_exists = false;

        // Se cargan los usuarios de un JSON
        try {
            JSONObject json = new JSONObject(loadJSONFromAsset());
            JSONArray paisesJsonArray = json.getJSONArray("users");
            for (int i = 0; i < paisesJsonArray.length(); i++) {
                JSONObject jsonObject = paisesJsonArray.getJSONObject(i);
                String datos[] = new String[5];
                datos[0] = jsonObject.getString("user");
                datos[1] = jsonObject.getString("password");
                datos[2] = jsonObject.getString("user_type");
                datos[3] = jsonObject.getString("city");
                datos[4] = jsonObject.getString("name");
                users.add(datos);
            }
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        add_friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = "";
                for( String[] u: users )
                {
                    if( u[0].equals(friend_username.getText().toString()) )
                    {
                        user_exists = true;
                        user = u[0];
                        /*
                        Acá se verificará que el nuevo amigo no sea amigo del usuario cuando no se usen Mocks
                         */
                        break;
                    }
                }

                if(user_exists){

                    if( bundle.getString("user").equals(user) ){
                        Toast.makeText(getApplicationContext(), "EL usuario es usted mismo", Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Amigo agregado exitosamente", Toast.LENGTH_LONG).show();
                        /*
                        Acá se agregará al amigo a la lista de amigos cuando no se usen Mocks
                         */
                    }

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "El usuario " + friend_username.getText().toString() + " no existe", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("users.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
