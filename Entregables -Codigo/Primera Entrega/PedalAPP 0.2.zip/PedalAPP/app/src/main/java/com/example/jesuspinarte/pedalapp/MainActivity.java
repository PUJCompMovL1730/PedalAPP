package com.example.jesuspinarte.pedalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText user;      // Variable que leerá el nombre del usuario
    EditText password;  // Variable que leerá la contaseña del usuario
    Spinner user_type;  // Variable que leerá el tipo de usuario
    Button sign_in;      // Variable que tomará las acciones del botón "Iniciar Sesión"
    boolean user_exists; // Variable que permite verificar si un usuario existe o no
    Button register;

    ArrayList<String[]> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        users = new ArrayList<String[]>();  // Lista de todos los usuarios

        user = (EditText) findViewById(R.id.et_username);
        password = (EditText) findViewById(R.id.et_password);
        user_type = (Spinner) findViewById(R.id.s_user_type);
        sign_in = (Button) findViewById(R.id.bt_signin);
        register = (Button) findViewById(R.id.bt_signup);

        user_exists = false;

        // Se cargan los usuarios de un JSON
        try {
            JSONObject json = new JSONObject(loadJSONFromAsset());
            JSONArray paisesJsonArray = json.getJSONArray("users");
            for (int i = 0; i < paisesJsonArray.length(); i++) {
                JSONObject jsonObject = paisesJsonArray.getJSONObject(i);
                String datos[] = new String[5];
                datos[0] = jsonObject.getString("user");
                datos[1] = jsonObject.getString("password");
                datos[2] = jsonObject.getString("user_type");
                datos[3] = jsonObject.getString("city");
                datos[4] = jsonObject.getString("name");
                users.add(datos);
            }
        } catch (JSONException ex) {
            ex.printStackTrace();
        }


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), SignUpActivity.class);
                startActivity(intent);
            }
        });
            // Proceso de iniciar sesión
            sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = "";
                String city = "";
                // Se verifica si el usuario existe
                for( String[] u: users )
                {
                    if( u[0].equals(user.getText().toString()) && u[1].equals(password.getText().toString()) && u[2].equals(user_type.getSelectedItem().toString()) )
                    {
                        user_exists = true;
                        city = u[3];
                        name = u[4];
                        break;
                    }
                }
                if( user_exists && "Persona".equals(user_type.getSelectedItem().toString()) ) {
                    Intent intent = new Intent(v.getContext(), ProfileActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("user", user.getText().toString());
                    bundle.putString("password", password.getText().toString());
                    bundle.putString("city", city);
                    bundle.putString("name", name);
                    intent.putExtra("bundle", bundle);
                    startActivity(intent, bundle);
                } else if( user_exists && "Empresa".equals(user_type.getSelectedItem().toString()) ) {
                    Intent intent = new Intent(v.getContext(), EnterpriseProfileActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("user", user.getText().toString());
                    bundle.putString("password", password.getText().toString());
                    bundle.putString("city", city);
                    bundle.putString("name", name);
                    intent.putExtra("bundle", bundle);
                    startActivity(intent, bundle);
                }
            }
        });

    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("users.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
