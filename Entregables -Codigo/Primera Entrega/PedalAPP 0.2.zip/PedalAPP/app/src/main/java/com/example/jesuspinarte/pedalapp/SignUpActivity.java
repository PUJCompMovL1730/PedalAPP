package com.example.jesuspinarte.pedalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    EditText textUsu;
    EditText textContr;

    Spinner spCiudades;
    Spinner spTipoUsuario;

    Button botonRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        textUsu = (EditText) findViewById(R.id.et_username);
        textContr = (EditText) findViewById(R.id.et_password);

        spCiudades = (Spinner) findViewById(R.id.s_cities);
        spTipoUsuario = (Spinner) findViewById(R.id.s_user_type);

        botonRegis = (Button) findViewById(R.id.bt_commit_signup);

        botonRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = textUsu.getText().toString();
                String contrasenia = textContr.getText().toString();

                String ciudad = (String) spCiudades.getSelectedItem();

                if(TextUtils.isEmpty(usuario) || TextUtils.isEmpty(contrasenia)){
                    CharSequence text = "Error: Complete los campos de usuario y contraseña";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(v.getContext(), text, duration);
                    toast.show();
                }else{
                    Intent intent = new Intent(v.getContext(),ProfileActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("user", usuario);
                    bundle.putString("password", contrasenia);
                    bundle.putString("city", spCiudades.getSelectedItem().toString());
                    bundle.putString("name", usuario);
                    intent.putExtra("bundle", bundle);
                    startActivity(intent);
                }
            }
        });


    }
}
