package com.example.jesuspinarte.pedalapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class EnterpriseProfileActivity extends AppCompatActivity {

    Intent intent_info;
    Bundle bundle;
    TextView username;
    TextView city;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enterprise_profile);

        intent_info = getIntent();
        bundle = intent_info.getBundleExtra("bundle");
        username = (TextView) findViewById(R.id.tv_username);
        city = (TextView) findViewById(R.id.tv_city);

        username.setText(bundle.getString("name"));
        city.setText(bundle.getString("city"));

    }
}
